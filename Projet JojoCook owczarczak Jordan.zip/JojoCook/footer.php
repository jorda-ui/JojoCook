<footer class="u-align-center u-clearfix u-footer u-grey-80 u-footer" id="sec-7a7f">
    <div class="u-clearfix u-sheet u-sheet-1">
        <p class="u-small-text u-text u-text-variant u-text-1">© 2024 JojoCook. Tous droits réservés.</p>
        <nav class="u-menu u-menu-dropdown u-offcanvas u-menu-1">
            <div class="menu-collapse">
                <a class="u-button-style u-nav-link" href="#">
                    <span class="u-icon"></span>
                    <span class="u-text">Menu</span>
                </a>
            </div>
            <div class="u-nav-container">
                <ul class="u-nav u-unstyled u-nav-1">
                    <li class="u-nav-item"><a class="u-button-style u-nav-link" href="À-propos-de.html">À propos de </a></li>
                    <li class="u-nav-item"><a class="u-button-style u-nav-link" href="Contact.html">Contact</a></li>
                    <li class="u-nav-item"><a class="u-button-style u-nav-link" href="privacy.html">Politique de confidentialité</a></li>
                    <li class="u-nav-item"><a class="u-button-style u-nav-link" href="terms.html">Conditions d'utilisation</a></li>
                </ul>
            </div>
        </nav>
    </div>
    <a href="#" class="u-back-to-top u-icon u-icon-circle u-opacity u-opacity-85 u-palette-1-base" style="height: 64px; width: 64px; margin-left: 0px; margin-right: auto; margin-top: 0px; background-image: none; right: 20px; bottom: 20px; padding: 15px;">
        <svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 551.13 551.13">
            <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-1d98"></use>
        </svg>
        <svg class="u-svg-content" enable-background="new 0 0 551.13 551.13" viewBox="0 0 551.13 551.13" xmlns="http://www.w3.org/2000/svg" id="svg-1d98">
            <path d="m275.565 189.451 223.897 223.897h51.668l-275.565-275.565-275.565 275.565h51.668z"></path>
        </svg>
    </a>
</footer>
